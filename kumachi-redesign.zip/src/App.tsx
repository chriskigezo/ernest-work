import { FormEvent, useEffect, useRef, useState } from "react"

const services = [
  {
    title: "Web Design",
    copy: "A site that looks like you and sells like it means it.",
    icon: "spark",
  },
  {
    title: "Web Development",
    copy: "A fast portfolio or store that works on any phone.",
    icon: "code",
  },
  {
    title: "Graphics Design",
    copy: "A look people remember, on every screen.",
    icon: "shape",
  },
  {
    title: "Content Marketing",
    copy: "Words that make people want your work.",
    icon: "type",
  },
  {
    title: "Digital Advertising",
    copy: "Put your work in front of people ready to buy.",
    icon: "signal",
  },
  {
    title: "Mobile Apps",
    copy: "Your own app and audience, when you're ready.",
    icon: "phone",
  },
]

const problems = [
  "You make great work and almost nobody sees it.",
  "Self-promotion feels awkward, and selling feels worse.",
  "Your website looks like a template, or doesn't exist.",
  "You're renting your audience from an algorithm.",
  "People say “starving artist” like it's a law of nature.",
]

const rotatingWords = ["sell", "get seen", "get paid", "grow"]

function Crack({ flip = false }: { flip?: boolean }) {
  return (
    <div className={`crack ${flip ? "crack--flip" : ""}`} aria-hidden="true">
      <svg viewBox="0 0 1200 34" preserveAspectRatio="none">
        <path d="M0 17 L140 16 L202 20 L250 8 L307 22 L362 14 L475 17 L522 4 L561 25 L608 15 L735 18 L779 9 L831 23 L884 14 L964 17 L1008 5 L1049 24 L1090 15 L1200 17" />
      </svg>
    </div>
  )
}

function ServiceIcon({ type }: { type: string }) {
  const common = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.5,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  }

  return (
    <svg viewBox="0 0 48 48" aria-hidden="true" {...common}>
      {type === "spark" && (
        <>
          <path d="M24 5c1.4 10.4 8.6 17.6 19 19-10.4 1.4-17.6 8.6-19 19-1.4-10.4-8.6-17.6-19-19C15.4 22.6 22.6 15.4 24 5Z" />
          <path d="M36 6v8M32 10h8" />
        </>
      )}
      {type === "code" && (
        <>
          <path d="m17 14-10 10 10 10M31 14l10 10-10 10M28 7l-8 34" />
        </>
      )}
      {type === "shape" && (
        <>
          <circle cx="18" cy="18" r="11" />
          <path d="M22 26h19v15H22zM28 7l13 19" />
        </>
      )}
      {type === "type" && (
        <>
          <path d="M8 10h32M24 10v29M15 39h18" />
          <path d="M8 10v7M40 10v7" />
        </>
      )}
      {type === "signal" && (
        <>
          <circle cx="12" cy="36" r="3" />
          <path d="M9 25c7.7 0 14 6.3 14 14M9 14c13.8 0 25 11.2 25 25M9 4c19.3 0 35 15.7 35 35" />
        </>
      )}
      {type === "phone" && (
        <>
          <rect x="12" y="4" width="24" height="40" rx="5" />
          <path d="M20 9h8M22 38h4" />
        </>
      )}
    </svg>
  )
}

function Reveal({
  children,
  className = "",
}: {
  children: React.ReactNode
  className?: string
}) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const node = ref.current
    if (!node) return
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          node.classList.add("is-visible")
          observer.unobserve(node)
        }
      },
      { threshold: 0.16 },
    )
    observer.observe(node)
    return () => observer.disconnect()
  }, [])

  return (
    <div ref={ref} className={`reveal ${className}`}>
      {children}
    </div>
  )
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [wordIndex, setWordIndex] = useState(0)
  const [heroScrolled, setHeroScrolled] = useState(false)
  const [formState, setFormState] = useState<"idle" | "success" | "error">(
    "idle",
  )

  useEffect(() => {
    let frame = 0
    const onScroll = () => {
      if (frame) return
      frame = window.requestAnimationFrame(() => {
        const maxScroll =
          document.documentElement.scrollHeight - window.innerHeight
        const pageProgress = maxScroll > 0 ? window.scrollY / maxScroll : 0
        const heroProgress = Math.min(
          1,
          window.scrollY / (window.innerHeight * 0.82),
        )

        document.documentElement.style.setProperty(
          "--scroll-progress",
          pageProgress.toFixed(4),
        )
        document.documentElement.style.setProperty(
          "--hero-progress",
          heroProgress.toFixed(4),
        )
        document.documentElement.style.setProperty(
          "--hero-crack",
          String(Math.round(1000 * (1 - heroProgress))),
        )
        document.documentElement.style.setProperty(
          "--hero-fade",
          String(1 - heroProgress * 0.64),
        )
        setWordIndex(
          Math.min(
            rotatingWords.length - 1,
            Math.floor(heroProgress * rotatingWords.length),
          ),
        )
        setHeroScrolled(heroProgress > 0.35)
        frame = 0
      })
    }

    onScroll()
    window.addEventListener("scroll", onScroll, { passive: true })
    window.addEventListener("resize", onScroll, { passive: true })
    return () => {
      window.removeEventListener("scroll", onScroll)
      window.removeEventListener("resize", onScroll)
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : ""
    return () => {
      document.body.style.overflow = ""
    }
  }, [menuOpen])

  const closeMenu = () => setMenuOpen(false)

  const submitForm = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = event.currentTarget
    if (!form.checkValidity()) {
      setFormState("error")
      form.reportValidity()
      return
    }
    setFormState("success")
    form.reset()
  }

  return (
    <main>
      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="Kumachi Studio home">
          <img
            src="/assets/kumachi-logo.png"
            alt="Kumachi Studio"
            width="721"
            height="269"
          />
        </a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#philosophy">Our philosophy</a>
          <a href="#services">What we do</a>
          <a href="#work">Work</a>
          <a href="#contact">Contact</a>
        </nav>
        <a className="button button--small header-cta" href="#contact">
          Tell us what you're making
        </a>
        <button
          className="menu-toggle"
          onClick={() => setMenuOpen((open) => !open)}
          aria-expanded={menuOpen}
          aria-controls="mobile-menu"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
        >
          <span />
          <span />
        </button>
        <div
          id="mobile-menu"
          className={`mobile-menu ${menuOpen ? "is-open" : ""}`}
        >
          <nav aria-label="Mobile navigation">
            <a href="#philosophy" onClick={closeMenu}>
              Our philosophy
            </a>
            <a href="#services" onClick={closeMenu}>
              What we do
            </a>
            <a href="#work" onClick={closeMenu}>
              Work
            </a>
            <a href="#contact" onClick={closeMenu}>
              Contact
            </a>
          </nav>
          <a className="button" href="#contact" onClick={closeMenu}>
            Tell us what you're making
          </a>
          <p>We empower endeavors.</p>
        </div>
      </header>

      <div className="chi-thread" aria-hidden="true">
        <span className="chi-thread-label">CHI</span>
        <i className="chi-thread-line" />
        <i className="chi-thread-spark">✦</i>
      </div>

      <section id="top" className={`hero ${heroScrolled ? "is-scrolled" : ""}`}>
        <div className="motes" aria-hidden="true">
          {Array.from({ length: 32 }, (_, index) => (
            <span
              key={index}
              style={
                {
                  "--x": `${(index * 37) % 100}%`,
                  "--y": `${(index * 53) % 100}%`,
                  "--delay": `${(index % 9) * -1.4}s`,
                  "--duration": `${9 + (index % 7)}s`,
                } as React.CSSProperties
              }
            />
          ))}
        </div>
        <div className="hero-inner">
          <p className="eyebrow hero-eyebrow">
            <span className="eyebrow-line" />
            We empower endeavors.
          </p>
          <h1>
            <span className="held-line">
              <span>Your work is powerful.</span>
              <svg
                viewBox="0 0 900 34"
                preserveAspectRatio="none"
                aria-hidden="true"
              >
                <path d="M0 18 L132 17 L198 23 L249 6 L302 27 L361 13 L481 19 L546 8 L593 25 L662 12 L733 19 L788 5 L839 24 L900 16" />
              </svg>
            </span>
            <span className="released-line">Let's get it out there.</span>
          </h1>
          <p className="hero-copy">
            Websites, stores, ads and apps that help creatives{" "}
            <span className="rotating-word" key={rotatingWords[wordIndex]}>
              {rotatingWords[wordIndex]}
            </span>
            . You make the work. We handle the tech.
          </p>
          <div className="hero-actions">
            <a className="button" href="#contact">
              Tell us what you're making <span aria-hidden="true">↗</span>
            </a>
            <a className="button button--secondary" href="#services">
              See how we help <span aria-hidden="true">↓</span>
            </a>
          </div>
        </div>
        <div className="hero-sun" aria-hidden="true">
          <i />
          <i />
          <i />
        </div>
        <div className="scroll-cue" aria-hidden="true">
          <span>Scroll to release</span>
          <i />
        </div>
        <div className="hero-sparks" aria-hidden="true">
          {Array.from({ length: 16 }, (_, index) => (
            <i key={index} style={{ "--i": index } as React.CSSProperties} />
          ))}
        </div>
      </section>

      <section className="section section--know" aria-labelledby="know-title">
        <div className="shell">
          <Reveal>
            <p className="section-index">01 / We know</p>
            <h2 id="know-title">We know.</h2>
            <p className="section-intro">
              Yeah, we've been there. We're still artists ourselves.
            </p>
          </Reveal>
          <div className="problem-list">
            {problems.map((problem, index) => (
              <Reveal className="problem" key={problem}>
                <span>0{index + 1}</span>
                <p>{problem}</p>
                <Crack flip={index % 2 === 1} />
              </Reveal>
            ))}
          </div>
          <Reveal className="know-closer">
            <p>It isn't.</p>
            <p>Let's fix that.</p>
          </Reveal>
        </div>
      </section>

      <Crack />

      <section
        id="philosophy"
        className="section section--philosophy"
        aria-labelledby="philosophy-title"
      >
        <div className="chi-orbit" aria-hidden="true">
          <span />
          <span />
          <span />
          <i>✦</i>
        </div>
        <div className="shell philosophy-grid">
          <div>
            <p className="section-index">02 / Our philosophy</p>
            <h2 id="philosophy-title">Chi goes into everything we make.</h2>
          </div>
          <Reveal className="philosophy-copy">
            <p>
              Every maker has chi: the life force that goes into the work. Kuma
              poured his into his craft, and then he noticed something. Chi
              grows when it's shared.
            </p>
            <p>
              So he built a studio where designers, developers, writers and
              strategists each bring their own: different experiences, different
              skills, one purpose. Together we breathe life into your goals,
              whether you know how the tech works or not.
            </p>
            <blockquote>
              You bring the spark.
              <br />
              We bring the breath.
            </blockquote>
            <div className="callout">
              <span aria-hidden="true">✦</span>
              No tech skills needed. That part is our job.
            </div>
          </Reveal>
        </div>
      </section>

      <Crack flip />

      <section
        id="services"
        className="section section--services"
        aria-labelledby="services-title"
      >
        <div className="shell">
          <Reveal className="section-heading">
            <div>
              <p className="section-index">03 / What we do</p>
              <h2 id="services-title">The tech that helps you sell.</h2>
            </div>
            <p className="section-intro">
              Pick what you need.
              <br />
              We'll handle how it works.
            </p>
          </Reveal>
          <div className="service-grid">
            {services.map((service, index) => (
              <Reveal className="service-card" key={service.title}>
                <div className="service-meta">
                  <span>0{index + 1}</span>
                  <ServiceIcon type={service.icon} />
                </div>
                <h3>{service.title}</h3>
                <p>{service.copy}</p>
                <i className="corner-crack" aria-hidden="true" />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section
        id="work"
        className="section section--work"
        aria-labelledby="work-title"
      >
        <div className="shell">
          <Reveal>
            <p className="section-index">04 / Selected work</p>
            <h2 id="work-title">Work that got out there.</h2>
            <p className="section-intro">Case studies are on the way.</p>
          </Reveal>
          <div className="work-grid">
            {[1, 2, 3].map((item) => (
              <article className="case-card" key={item}>
                <span className="case-number">0{item}</span>
                <p className="case-label">Client name / what they make</p>
                <div className="case-row">
                  <span>The problem</span>
                  <strong>Placeholder text</strong>
                </div>
                <div className="case-row">
                  <span>What we built</span>
                  <strong>Placeholder text</strong>
                </div>
                <div className="case-row">
                  <span>What changed</span>
                  <strong>Placeholder text</strong>
                </div>
              </article>
            ))}
            <article className="case-card case-card--cta">
              <span aria-hidden="true">✦</span>
              <h3>Your work could be next.</h3>
              <a className="button" href="#contact">
                Tell us what you're making
              </a>
            </article>
          </div>
        </div>
      </section>

      <section
        id="contact"
        className="section section--contact"
        aria-labelledby="contact-title"
      >
        <div className="contact-glow" aria-hidden="true" />
        <div className="shell contact-grid">
          <div>
            <p className="section-index">05 / Start something</p>
            <h2 id="contact-title">Ready to get it out there?</h2>
            <p className="contact-subline">Tell us what you're making.</p>
          </div>
          <form onSubmit={submitForm} noValidate>
            <label>
              <span>Name</span>
              <input name="name" type="text" placeholder="Your name" required />
            </label>
            <label>
              <span>Email</span>
              <input
                name="email"
                type="email"
                placeholder="you@example.com"
                required
              />
            </label>
            <label className="full-field">
              <span>What do you make?</span>
              <textarea
                name="project"
                placeholder="Tell us about your work and what you want to make possible."
                rows={3}
                required
              />
            </label>
            <label className="full-field">
              <span>Link to your work</span>
              <input name="link" type="url" placeholder="https://" />
            </label>
            <div className="form-submit full-field">
              <button className="button" type="submit">
                Send it our way <span aria-hidden="true">↗</span>
              </button>
              <p className={`form-status ${formState}`} aria-live="polite">
                {formState === "success" &&
                  "Received. Your work is on its way to us."}
                {formState === "error" &&
                  "Please complete the required fields before sending."}
              </p>
            </div>
          </form>
        </div>
      </section>

      <footer>
        <div className="shell footer-top">
          <a className="wordmark" href="#top" aria-label="Kumachi Studio home">
            <img
              src="/assets/kumachi-logo.png"
              alt="Kumachi Studio"
              width="721"
              height="269"
            />
          </a>
          <p>We empower endeavors.</p>
          <div className="footer-links">
            <a href="mailto:hello@kumachistudio.com">hello@kumachistudio.com</a>
            <a href="#instagram">Instagram</a>
            <a href="#linkedin">LinkedIn</a>
          </div>
        </div>
        <div className="shell footer-bottom">
          <p>© {new Date().getFullYear()} Kumachi Studio</p>
          <p>Made with chi, by artists for artists.</p>
        </div>
      </footer>
    </main>
  )
}

export default App
